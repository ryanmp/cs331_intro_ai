Project 2: TicTacToe

CS331 - AI

Project by:
Ryan Phillips

email:
philliry@onid.oregonstate.edu

player1 & player2 can be either:
'human', 'random', or 'minimax'

you can run this via commandline or using the gui

commandline only:
$ python tictactoe.py player1 player2

gui:
$ python ticgui.py player1 player2


note:
the generation of the minimax gametree hasn't been optimized and could take a few minutes on slow hardware
