Assignment:

http://classes.engr.oregonstate.edu/eecs/spring2014/cs331/assignments.html